# Socket.IO chat example

This is the source code for a very simple chat example used for the [Tutorial](https://socket.io/docs/v4/tutorial/introduction) guide of the Socket.IO website.

You can run this example directly in your browser on:

- [CodeSandbox](https://codesandbox.io/p/sandbox/github/socketio/chat-example?file=index.js)
- [StackBlitz](https://stackblitz.com/github/socketio/chat-example?file=index.js)
- [Repl.it](https://repl.it/github/socketio/chat-example)
